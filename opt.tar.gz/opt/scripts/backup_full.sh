#! /bin/bash

FECHA=$(date +%Y%m%d)

ORIGEN=$1
DESTINO=$2

if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

if [[ ! -d "$ORIGEN" ]]; then 
	echo "Error: El directorio de origen $ORIGEN no existe."
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio de destino $DESTINO no existe."
	exit 1
fi

NOMBRE_BKP=$(basename $ORIGEN)_bkp_${FECHA}.tar.gz
tar -czvf $DESTINO/$NOMBRE_BKP $ORIGEN

echo "Backup completado correctamente."
