#! /bin/bash

FECHA=$(date +%Y%m%d)
HORA=$(date +%H%M%S)
LOG="/root/backup.log"

ORIGEN=$1
DESTINO=$2

#Función para registrar los logs del script
log() {
	echo "[$FECHA $HORA] $1" >> "$LOG" 
}

# Agregar la parte del argumento -help
if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	log "Uso de argumento -help."
	exit 0
fi

# Validar cantidad de argumentos
if [[ $# -lt 2 ]]; then
	echo "Error: Se debe indicar origen y destino"
	log "Error: argumentos insuficientes. Origen='$ORIGEN' Destino='$DESTINO'"
	exit 1
fi

# Validamos directorios de origen y destino
if [[ ! -d "$ORIGEN" ]]; then 
	echo "Error: El directorio de origen $ORIGEN no existe."
	log "Error: Origen no existe: $ORIGEN"
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio de destino $DESTINO no existe."
	log "Error: Destino no existe: $DESTINO"
	exit 1
fi

# Validar que los sistemas de archivos estén montados
if [[ "$ORIGEN" == "/www_dir" ]] && ! mountpoint -q "$ORIGEN"; then
    echo "Error: El sistema de archivos de origen '$ORIGEN' no está montado."
    log "Error: Origen no montado: $ORIGEN"
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: El sistema de archivos de destino '$DESTINO' no está montado."
    log "Error: Destino no montado: $DESTINO"
    exit 1
fi

NOMBRE_BKP=$(basename $ORIGEN)_bkp_${FECHA}.tar.gz
ARCHIVO_DESTINO="$DESTINO/$NOMBRE_BKP"

TAR_OUTPUT=$(tar -czf "$ARCHIVO_DESTINO" "$ORIGEN" 2>&1)
EXIT_CODE=$?

# Filtrar el warning de "Eliminando la '/' inicial"
TAR_OUTPUT_CLEAN=$(echo "$TAR_OUTPUT" | grep -v "Eliminando la \`/' inicial")

# Validamos si el backup fue exitoso
if [[ $EXIT_CODE -eq 0 ]]; then
	echo "Backup del ORIGEN $ORIGEN completado correctamente."
	log "Backup del ORIGEN $ORIGEN completado correctamente."
else 
	echo "$TAR_OUTPUT_CLEAN" >> "$LOG"
	log "Error al realizar el backup del ORIGEN $ORIGEN."
	exit 1
fi
