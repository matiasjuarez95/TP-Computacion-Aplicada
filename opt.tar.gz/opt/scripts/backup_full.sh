#! /bin/bash

FECHA=$(date +%Y%m%d)
HORA=$(date +%H%M%S)
LOG="/var/log/backup.log"

ORIGEN=$1
DESTINO=$2

#Función para registrar los logs del script
log() {
	echo "[$FECHA $HORA] $1" >> "$LOG" 
}

# Agregar la parte del argumento -help
if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	log "Uso de argumento -help."
	exit 0
fi

# Validar cantidad de argumentos
if [[ $# -lt 2 ]]; then
	echo "Error: Se debe indicar origen y destino"
	log "Error: argumentos insuficientes. Origen='$ORIGEN' Destino='$DESTINO'"
	exit 1
fi

# Validamos directorios de origen y destino
if [[ ! -d "$ORIGEN" ]]; then 
	echo "Error: El directorio de origen $ORIGEN no existe."
	log "Error: Origen no existe: $ORIGEN"
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio de destino $DESTINO no existe."
	LOG "Error: Destino no existe: $DESTINO"
	exit 1
fi

NOMBRE_BKP=$(basename $ORIGEN)_bkp_${FECHA}.tar.gz
ARCHIVO_DESTINO="$DESTINO/$NOMBRE_BKP"

tar -czvf "$ARCHIVO_DESTINO" "$ORIGEN" >> "$LOG" 2>&1

# Validamos si el backup fue exitoso
if [[ $? -eq 0 ]]; then
	echo "Backup completado correctamente."
	log "Backup completado correctamente."
else 
	echo "Error al realizar el backup."
	log "Error al realizar el backup."
	exit 1
fi
